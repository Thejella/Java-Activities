//Submitted by: Xian Benedict G. Yee BsCompE2 EP1
public class timeconversion
{
    public static void main(String[] args) {
    float hours = 5;
    float seconds = 6000;
    System.out.println("Given:\b");
    System.out.println("5 Hours\b");
    System.out.println("6000 Seconds\n");
    System.out.println("Converted:\b");
    System.out.println("5 hours = " + (hours*60) + " Minutes");
    System.out.println("6000 minutes = " + (seconds/60) + " Minutes");
    }
}
