//Submitted By: Xian Benedict G. Yee BSCompE 2 EP1
public class arithmeticoperators
{
    public static void main(String[] args) {
        int a=8, b=5, x=10, y=3;
        System.out.println("Variables... \b");
        System.out.println("a=8\b");
        System.out.println("b=5\b");
        System.out.println("x=10\b");
        System.out.println("y=3\n");
        
        System.out.println("Exponention... \b");
        System.out.println("a^b= " + Math.pow(a, b) + "\b");
        System.out.println("x^y= " + Math.pow(x, y) + "\n");
        
        System.out.println("Multiplication... \b");
        System.out.println("a*b= " + (a*b) + "\b");
        System.out.println("x*y= " + (x*y) + "\n");
        
        System.out.println("Dividing... \b");
        System.out.println("a/b= " + (a/b) + "\b");
        System.out.println("x/y= " + (x/y) + "\n");
        
        System.out.println("Adding... \b");
        System.out.println("a+b= " + (a+b) + "\b");
        System.out.println("x+y= " + (x+y) + "\n");
        
        System.out.println("Substracting... \b");
        System.out.println("a-b= " + (a-b) + "\b");
        System.out.println("x-y= " + (x-y) + "\n");
        
        System.out.println("Finding the remainder... \b");
        System.out.println("a%b= " + (a%b) + "\b");
        System.out.println("x%y= " + (x%y) + "\n");
    }
}

