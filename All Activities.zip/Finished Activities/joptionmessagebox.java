//Submitted by: Xian Benedict G. Yee BSCompE2 EP1
import javax.swing.JOptionPane;
public class joptionmessagebox
{
    public static void main(String[] args) {
    JOptionPane.showMessageDialog(null, "Hello User!");
    }
}
