//Submitted by: Xian Benedict G. Yee BsCompE2 EP1
public class logicalnot
{
    public static void main(String[] args) {
    boolean val1=true;
    boolean val2=false;
    System.out.println("Displaying variables…");
    System.out.println("val1=true");
    System.out.println("val2=false\n");
    System.out.println("Displaying results…");
    System.out.println(!val1);
    System.out.println(!val2);
    }
}
