//Submitted by: Xian Benedict G. Yee BsCompE2 EP1
public class vowelsorconsonant
{
    public static void main(String[] args) {
    char Letter = 'a';
    System.out.println("Printing character...");
    System.out.println(Letter);
    System.out.println("Evaluating...");
    if (Letter != 'a' && Letter != 'e' && Letter != 'i' && Letter != 'o' && Letter != 'u')
    System.out.println("Result: Consonant"); 
    else System.out.println("Result: Vowel"); 
    
    }
}