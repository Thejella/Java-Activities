//Submitted by: Xian Benedict G. Yee BsCompE2 EP1
public class winningpercentage
{
    public static void main(String[] args) {
    float wins = 19;
    float games = 25;
    float winningpercent = (wins/games) * 100;
    System.out.println("Printing the data from the last tournament...");
    System.out.println("Won games: 19");
    System.out.println("Lost games: 6");
    System.out.println("Total played games: 25\n");
    System.out.println("Computing winning percentage....");
    System.out.println("Result: " + winningpercent + "%");
    }
}
