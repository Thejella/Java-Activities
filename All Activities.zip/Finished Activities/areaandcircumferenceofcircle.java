//Submitted By: Xian Benedict G. Yee BSCompE 2 EP1
public class areaandcircumferenceofcircle
{
    public static void main(String[] args) {
    int radius = 14;
    System.out.println("Given:\b");
    System.out.println("Radius= 14\n");
    System.out.println("Computing for Circumference...\b");
    System.out.println("Result: " + (2*Math.PI*radius) + "\n");
    System.out.println("Computing for the Area...\b");
    System.out.println("Result: " + Math.PI*Math.pow(radius, 2) + "\b");
    }
}

