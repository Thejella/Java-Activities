//Submitted by: Xian Benedict G. Yee BsCompE2 EP1
public class incrementanddecrementoperators
{
    public static void main(String[] args) {
    boolean x = true;
    int y=5;
    int a=3;
    int b;
    System.out.println("Variables:\b");
    System.out.println("boolean x = true;");
    System.out.println("int y=5;");
    System.out.println("int a=3;");
    System.out.println("int b;\n");
    System.out.println("Output:\b");
    System.out.println(x);
    System.out.println(++y * a);
    System.out.println(x != y > a);
    System.out.println(--a);
    System.out.println(--y);
    }
}
