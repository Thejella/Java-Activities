//Submitted by: Xian Benedict G. Yee BsCompE2 EP1
public class whilelooprepetitionstructure
{
    public static void main(String[] args) {
    int i = 1;
    System.out.println("Printing...");
    while ( i < 6 ){
    System.out.print(i + "\n");
    i++;
    }
    }
}
