//Submitted by: Xian Benedict G. Yee BsCompE2 EP1
import java.io.*;
public class lovejava
{
    public static void main(String[] args)throws IOException{
    int i = 3;
    while ( i > 0 ){
    System.out.print("I love Java!\n");
    i--;
    }
    }
}
