//Submitted by: Xian Benedict G. Yee BSCompE 2 EP1
public class areaofthetriangle
{
    public static void main(String[] args) {
	int base = 5;
	int height = 12;
        System.out.println("Given:\b");
        System.out.println("Base=5cm\b");
        System.out.println("Height=12cm\n");
        System.out.println("Computing for the Area of Triangle...");
        System.out.println("Area= " + (base*height)/2 + "\n");
    }
}
