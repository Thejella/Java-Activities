//Submitted by: Xian Benedict G. Yee BsCompE2 EP1
public class oddoreven
{
    public static void main(String[] args) {
    int num1 = 1778;
    String oddoreven = ((num1 % 2) == 0)? "EVEN": "ODD";
    System.out.println("Printing Integer...");
    System.out.println(num1 + "\n");
    System.out.println("Evaluating...\b");
    System.out.println("Results: " + oddoreven);
    }
}
